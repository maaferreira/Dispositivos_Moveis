function Cabecalho() {
  return <h1>Minha Página Web</h1>;
}

export default Cabecalho;
