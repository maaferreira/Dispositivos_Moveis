function Mensagem() {
  return <p>Este é um componente reutilizável.</p>;
}

export default Mensagem;
