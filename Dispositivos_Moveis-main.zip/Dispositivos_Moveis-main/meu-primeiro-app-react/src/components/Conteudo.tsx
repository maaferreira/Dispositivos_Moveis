function Conteudo() {
  return <p>Este é o conteúdo principal.</p>;
}

export default Conteudo;
