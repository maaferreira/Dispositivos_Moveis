function Meio() {
  return <main>Conteúdo do meio da página</main>;
}

export default Meio;
