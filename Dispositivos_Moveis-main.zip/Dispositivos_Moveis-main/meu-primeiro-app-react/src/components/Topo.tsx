function Topo() {
  return <header>Topo da página</header>;
}

export default Topo;
