function Base() {
  return <footer>Rodapé da página</footer>;
}

export default Base;
