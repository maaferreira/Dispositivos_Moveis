function Rodape() {
  return <footer>Todos os direitos reservados.</footer>;
}

export default Rodape;
