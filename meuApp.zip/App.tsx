import React from "react";
import { ScrollView, StyleSheet } from "react-native";
import Contador from "./components/Contador";
import Tamanhos from "./components/Tamanhos";
import { Greeting } from "./components/Greeting";
import ExemploImagem from "./components/ExemploImagem";

export default function App() {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Contador />
      <Tamanhos />
      <Greeting nome="Águia" size={28} />
      <ExemploImagem />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 20,
  },
});