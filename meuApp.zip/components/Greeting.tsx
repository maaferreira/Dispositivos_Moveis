import React, { Component } from "react";
import { Text } from "react-native";

type GreetingProps = {
  nome: string;
  size?: number;
};

export class Greeting extends Component<GreetingProps> {
  render() {
    const { nome, size = 20 } = this.props;
    return <Text style={{ fontSize: size, marginVertical: 20 }}>Olá, {nome}!</Text>;
  }
}