import React from "react";
import { View, Text, StyleSheet, Image, useWindowDimensions } from "react-native";

export default function Tamanhos() {
  const { width } = useWindowDimensions();

  return (
    <View style={styles.container}>
      <Text style={styles.sectionTitle}>Seção A - Tamanho Fixo</Text>
      <View style={styles.fixedContainer}>
        <View style={styles.fixedBox}><Text>1</Text></View>
        <View style={styles.fixedBox}><Text>2</Text></View>
        <View style={styles.fixedBox}><Text>3</Text></View>
      </View>

      <Text style={styles.sectionTitle}>Seção B - Tamanho Dinâmico</Text>
      <View style={styles.dynamicContainer}>
        <Image
          source={{ uri: "https://i.pinimg.com/236x/dc/2f/67/dc2f67e2c786f2908fe1c97e10d83cb6.jpg" }}
          style={{
            width: width * 0.8,
            aspectRatio: 3 / 4,
            borderWidth: 1,
            borderColor: "#333",
            borderRadius: 12,
          }}
          resizeMode="cover"
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginVertical: 20,
    width: "100%",
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "bold",
    marginVertical: 10,
  },
  fixedContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginBottom: 20,
  },
  fixedBox: {
    width: 60,
    height: 60,
    backgroundColor: "#4CAF50",
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 8,
  },
  dynamicContainer: {
    alignItems: "center",
    marginTop: 10,
  },
});