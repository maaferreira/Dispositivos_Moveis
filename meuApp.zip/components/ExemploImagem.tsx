import React from "react";
import { View, Text, StyleSheet, Image, useWindowDimensions } from "react-native";

export default function ExemploImagem() {
  const { width } = useWindowDimensions();

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Exemplo com Imagem</Text>
      <Image
        source={{ uri: "https://i.pinimg.com/236x/dc/2f/67/dc2f67e2c786f2908fe1c97e10d83cb6.jpg" }}
        style={{
          width: width * 0.8,
          aspectRatio: 3 / 4,
          borderRadius: 12,
          borderWidth: 2,
          borderColor: "#333",
        }}
        resizeMode="cover"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginVertical: 20,
    alignItems: "center",
  },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 10,
  },
});